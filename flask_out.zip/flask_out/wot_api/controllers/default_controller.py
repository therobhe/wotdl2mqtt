from .. import hub
import inspect
from io import StringIO
import tokenize
import re

import connexion
import six

from wot_api import util


def get_lights():  # noqa: E501
    """GetLights request on device LightSensor1

     # noqa: E501


    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def heating_off():  # noqa: E501
    """heating_off request on device relay heating

     # noqa: E501


    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def heating_on(power):  # noqa: E501
    """heating_on request on device relay heating

     # noqa: E501

    :param power: 
    :type power: float

    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def shades_close():  # noqa: E501
    """ShadesClose request on device shades

     # noqa: E501


    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def shades_open():  # noqa: E501
    """ShadesOpen request on device shades

     # noqa: E501


    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def switch_off_lamp():  # noqa: E501
    """SwitchOffLamp request on device philipshue

     # noqa: E501


    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def switch_on_lamp():  # noqa: E501
    """SwitchOnLamp request on device philipshue

     # noqa: E501


    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def switch_tv_off():  # noqa: E501
    """SwitchTvOff request on device samsungTV

     # noqa: E501


    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def switch_tv_on(path_param, query_param1=None):  # noqa: E501
    """SwitchTVOn request on device samsungTV

     # noqa: E501

    :param path_param: 
    :type path_param: str
    :param query_param1: 
    :type query_param1: str

    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 



def thermostat_set(target_temperature):  # noqa: E501
    """thermostat_set request on device thermostat

     # noqa: E501

    :param target_temperature: 
    :type target_temperature: float

    :rtype: None
    """
    
    request_device = r'(.*) request on device (.*)'
    pattern = re.compile(request_device)
    
    function = inspect.currentframe()
    function_name = function.f_code.co_name
    arguments = function.f_code.co_varnames[0:function.f_code.co_argcount]
    kwargs = {}
    for argument in arguments:
        kwargs[argument] = function.f_locals[argument]
    source_code = inspect.getsource(function.f_code)
    comments = StringIO(source_code)
    
    strings = [token for type, token, _, _, _ in tokenize.generate_tokens(comments.readline) if type == tokenize.STRING]
    
    matches = pattern.search(strings[0].strip('"'))
    request = matches.group(1)
    device = matches.group(2)
       
    return hub.invoke_implementation(function_name, kwargs, request, device)
 

